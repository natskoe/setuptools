def adiciona_um(numero):
    return numero + 1